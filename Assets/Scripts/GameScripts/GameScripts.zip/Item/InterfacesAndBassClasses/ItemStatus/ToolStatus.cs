using System;

[Serializable]
public class ToolStatus: ItemStatus
{
    public bool ToolOn;
}
