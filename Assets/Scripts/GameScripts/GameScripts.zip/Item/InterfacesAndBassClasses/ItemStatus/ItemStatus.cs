public class ItemStatus
{
    
}
