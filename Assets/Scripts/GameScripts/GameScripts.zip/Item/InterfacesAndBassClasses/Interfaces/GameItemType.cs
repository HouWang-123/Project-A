public enum GameItemType      // 物品类型
{
    UNDEFINED,
    Weapon,
    Food,
    ToolItem,
    TinyItem,
    Throwable,
    SceneObject,
    Jewelry
}
